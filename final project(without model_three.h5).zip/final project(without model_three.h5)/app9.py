#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jun 30 11:46:20 2021

@author: mrli
"""
# coding=utf-8
# import sys
import os
# from PIL import Image as pil_image
from werkzeug.datastructures import ImmutableMultiDict

# Keras

from tensorflow import keras
# from tensorflow.keras.models import Model
from keras.preprocessing import image

# Flask utils
from flask import Flask, redirect, url_for, request, render_template, jsonify
from werkzeug.utils import secure_filename
#from gevent.pywsgi import WSGIServer

import numpy as np
import pickle
import tensorflow as tf
import socket
from keras.models import load_model
#import h5py
from tensorflow.keras.applications.vgg16 import VGG16
from tensorflow.keras import models, layers

# NLP
import spacy
import textacy





# def loss_max(y_true, y_pred):
#     from keras import backend as K
#     return K.max(K.abs(y_pred - y_true), axis=-1)
#HOST = '127.0.0.1'  # Standard loopback interface address (localhost)
#PORT = 65432        # Port to listen on (non-privileged ports are > 1023)

app=Flask(__name__,template_folder='templates')
Model = load_model('model_three.h5', compile = False)
#Model = load_model('')
#Model.compile(loss='categorical_crossentropy',optimizer='adam',metrics=['accuracy'])
#Model._make_predict_function()
#Model.compile(loss='binary_crossentropy', optimizer = myOptimizer, metrics=[keras.metrics.binary_accuracy, metrics.binary_PTA, metrics.binary_PFA])



lesion_classes_dict = {
    0 : '/static/0.png',
    1 : '/static/1.png',
    2 : '/static/2.png',
    3 : '/static/3.png'
}

basedir = os.path.abspath(os.path.dirname(__file__))

nlp = spacy.load("en_core_web_trf")

def Sex_nlp(sentence):
    doc = nlp(sentence)
    #tokenize the sentence and extract noun
    noun = []
    for token in doc:
        if token.pos_ == "NOUN":
            noun.append(str(token))
    #Identify Library        
    Sex = ['man', 'men', 'male', 'boy', 'girl', 'female', 'woman', 'women', 'mr', 'mrs', 'miss']
    male = ['man', 'men', 'male', 'boy','mr']
    female = ['girl', 'female', 'woman', 'women','mrs', 'miss']
    #Check for keywords
    sex = []
    for i in noun:
        for j in Sex:
            if i.lower() == j:
                sex.append(i.lower())
                break
    #Check for unkown
    if not sex:
        sex.append("unknown")
        return sex
    
    #Check for male or female
    check_male = any(item in sex for item in male)
    check_female = any(item in sex for item in female)
    
    if check_male is True:
        sex = ['male']
        return sex
    elif check_female is True:
        sex = ['female']
        return sex
    elif (check_male and check_female) is True:
        sex = ['unknown']
        return sex
    else:
        return sex       
    return sex

def Body_nlp(sentence):
    doc = nlp(sentence)
    
    #tokenize the sentence and extract noun
    noun = []
    for token in doc:
        if token.pos_ == "NOUN":
            noun.append(str(token))
            
    #Identify for keywords
    Body = ['face', 'lower extremity', 'upper extremity', 'back', 'trunk', 'chest', 'abdomen', 'scalp',
       'neck', 'unknown', 'hand', 'ear', 'foot', 'genital', 'acral']
    
    #Check for keywords
    body = []
    for i in noun:
        for j in Body:
            if i.lower() == j:
                body.append(i.lower())
                break
    if not body:
        body.append("unknown")
    return body



def model_predict(img_path, Model, sex, location):
    # Sex
    sex_a = [1, 0, 0]
    if sex == 'male' or 'Male':
        sex_a = [0, 1, 0]
    elif sex == 'female' or 'Female':
        sex_a = [0, 0, 1]
    feat = np.array(sex_a)
    # Location
    if location == 'abdomen':
        feat = np.concatenate((feat, tf.one_hot(0, 15)))# - 0.5))
    elif location == 'scalp':
        feat = np.concatenate((feat, tf.one_hot(1, 15)))# - 0.5))
    elif location == 'lower extremity':
        feat = np.concatenate((feat, tf.one_hot(2, 15)))# - 0.5))
    elif location == 'trunk':
        feat = np.concatenate((feat, tf.one_hot(3, 15)))# - 0.5))
    elif location == 'upper extremity':
        feat = np.concatenate((feat, tf.one_hot(4, 15)))# - 0.5))
    elif location == 'back':
        feat = np.concatenate((feat,tf.one_hot(5, 15)))# - 0.5))
    elif location == 'neck':
        feat = np.concatenate((feat,tf.one_hot(6, 15)))# - 0.5))
    elif location == 'face':
        feat = np.concatenate((feat,tf.one_hot(7, 15)))# - 0.5))
    elif location == 'chest':
        feat = np.concatenate((feat,tf.one_hot(8, 15)))# - 0.5))
    elif location == 'foot':
        feat = np.concatenate((feat,tf.one_hot(9, 15)))# - 0.5))
    elif location == 'ear':
        feat = np.concatenate((feat,tf.one_hot(10, 15)))# - 0.5))
    elif location == 'hand':
        feat = np.concatenate((feat,tf.one_hot(12, 15)))# - 0.5))
    elif location == 'acral':
        feat = np.concatenate((feat,tf.one_hot(13, 15)))# - 0.5))
    elif location == 'genital':
        feat = np.concatenate((feat,tf.one_hot(14, 15)))# - 0.5))
    else:
        feat = np.concatenate((feat,tf.one_hot(11, 15)))# - 0.5))
    
    VGG_load = VGG16(weights='imagenet', include_top=False)
    model = models.Sequential()
    model.add(VGG_load)
    model.add(layers.Flatten())
    
    #image preprocessing 
    img = image.load_img(img_path, target_size= (224,224))
    img = image.img_to_array(img)
    img = np.expand_dims(img, axis=0)
    img = tf.keras.applications.vgg16.preprocess_input(img)
    preds = model.predict(img).reshape(25088)
    preds = np.concatenate((preds,feat))
    
    #predict cancer type
    preds = Model.predict(np.array([preds]))
    return preds



@app.route('/', methods=['GET'])
def index():
    # Main page
    return render_template('new.html')
    #return render_template('index.html')


@app.route('/predict', methods=['GET', 'POST'])
def upload():
        # Get the file from post request
    if request.method == 'POST':  #OK
        imgData = request.files.get('file')
        sex = request.form.get('sex')
        sex = str(Sex_nlp(sex))
        location = request.form.get('location')
        location = str(Body_nlp(location))
        #imgData = request.files.to_dict()
        #imgData = request.files.get('it')
        # imgData = imgData.get('it').read()
            # Save the file to ./uploads
        #for filename, file in request.FILES.iteritems():
         #   name = request.FILES[filename].name
        if imgData != None:
        # Make prediction

            path = basedir + "\\static\\upload\\img\\"
            imgName = imgData.filename
            file_path = path + imgName
            imgData.save(file_path)
            
            # Make prediction
            preds = model_predict(file_path, Model, sex, location)
    
            # Process your result for human
            pred_class = preds.argmax(axis=-1)            # Simple argmax
            #pred_class = decode_predictions(preds, top=1)   
            pr = lesion_classes_dict[pred_class[0]]
            result =str(pr) 
            return result
    # 如果前面报错，这里就会显示错误，并且报错切换网页
    return str(list(request.files.keys()))




if __name__ == "__main__":
    app.run(port=65432, debug = False)

"""if __name__=='__main__':
  app.debug=True
  app.run('0.0.0.0', port=5001) #port can be anything higher than 5000.
"""